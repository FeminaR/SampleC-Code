﻿using System;
using System.Collections.Generic;

namespace AdditionLargeNumbers
{
   public class Program
    {
		public void findsum(string a, string b)
		{
			List<int> finalsum = new List<int>();
			int carry = 0;


			int i = a.Length - 1;
			int j = b.Length - 1;
			while ((i >= 0) && (j >= 0))
			{
				int x = (a[i] - '0') + (b[j] - '0') + carry; // Calculate the sum of digit in final sum by adding respective digits with previous carry.
				finalsum.Add(x % 10);                       // Store the respective digit of the final sum in a vector.
				carry = x / 10;
				i--;
				j--;
			}

			while (i >= 0)
			{
				int x = (a[i] - '0') + carry;
				finalsum.Add(x % 10);
				carry = x / 10;                         // update the carry from each step
				i--;
			}

			while (j >= 0)
			{
				int x = (b[j] - '0') + carry;
				finalsum.Add(x % 10);
				carry = x / 10;
				j--;
			}


			while (carry != 0)
			{
				finalsum.Add(carry % 10);
				carry = carry / 10;
			}

			for (int k = finalsum.Count - 1; k >= 0; k--)
			{
				Console.Write(finalsum[k]);
			}
			Console.Write("\n");
		}
		public static void Main()
		{
			Program p = new Program();
			p.findsum("101", "10");
			Console.WriteLine("Addition of 18383838838383838838383838383823838301 and 3737377373737373773737373737737317 is: ");
			p.findsum("18383838838383838838383838383823838301", "3737377373737373773737373737737317");

		}

	}
}
